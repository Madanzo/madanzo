
import { Button } from '@/components/ui/button';
import { Clock, MapPin, ShoppingCart } from 'lucide-react';

const Hero = () => {
  return (
    <section className="hero-gradient text-white py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Satisfying Your <span className="text-peach-200">KRAVINGS</span>
            <br />
            One Delivery at a Time
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-pink-100 animate-fade-in">
            Premium cannabis delivery across LA County in just 20-45 minutes
          </p>

          <div className="flex flex-col md:flex-row items-center justify-center gap-6 mb-10">
            <div className="flex items-center space-x-2">
              <Clock className="w-6 h-6 text-peach-300" />
              <span className="text-lg">20-45 Min Delivery</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="w-6 h-6 text-peach-300" />
              <span className="text-lg">LA County Wide</span>
            </div>
            <div className="flex items-center space-x-2">
              <ShoppingCart className="w-6 h-6 text-peach-300" />
              <span className="text-lg">$30 Minimum</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <Button size="lg" className="bg-white text-pink-600 hover:bg-gray-100 text-lg px-8 py-3">
              View Menu
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-pink-600 text-lg px-8 py-3">
              Check Delivery Area
            </Button>
          </div>

          <p className="mt-8 text-sm text-pink-100">
            Licensed Cannabis Retailer • License #C9-000555-LIC • 21+ Only
          </p>
        </div>
      </div>
    </section>
  );
};

export default Hero;
