# MerkadAgency.ai Website

## Project info

**URL**: https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID

## Tech Stack

This project is built with a modern tech stack focused on performance and developer experience:

- **React** - A JavaScript library for building user interfaces
- **TypeScript** - For type safety and better developer experience
- **Tailwind CSS** - A utility-first CSS framework
- **Shadcn/UI** - A collection of re-usable components
- **React Router** - For client-side routing
- **Lucide Icons** - Beautiful open source icons

## Features

- Responsive design that works on all devices
- Modern, dark theme with beautiful gradients
- Optimized for performance
- SEO friendly
- Easy to maintain and extend

## How to run locally

```bash
npm install
npm run dev
```

## Deployment

Visit [Lovable](https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID) and click on Share -> Publish.
