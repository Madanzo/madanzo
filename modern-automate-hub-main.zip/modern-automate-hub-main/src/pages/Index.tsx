import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import QuickBenefits from "@/components/QuickBenefits";
import { PricingSection } from "@/components/sections/PricingSection";
import { BenefitsSection } from "@/components/sections/BenefitsSection";
import { TestimonialsSection } from "@/components/sections/TestimonialsSection";
import { BlogSection } from "@/components/sections/BlogSection";
import Footer from "@/components/Footer";
import { Bot, BarChart, MessageSquare } from "lucide-react";

const pricingPlans = [
  {
    title: "Starter Plan",
    description: "Get started with our affordable Starter plan, perfect for basic website needs!",
    icon: "🚀",
    color: "text-purple-400",
    features: [
      "3-Page Website",
      "On-Page SEO",
      "SMS and Email Automations",
      "Missed Call Text Back",
      "Lead Management App",
      "Contact Form and Chat Widget"
    ]
  },
  {
    title: "Unlimited Plan",
    description: "Scale your business with our Unlimited Plan, designed for growing businesses.",
    icon: "⚡",
    color: "text-orange-400",
    features: [
      "4-Page Website",
      "Everything In Starter+",
      "Advanced SMS and Email Automations",
      "Google Reviews Automation",
      "2/Month Reel Video Editing Service",
      "Payment Processing",
      "Calendar Booking System"
    ]
  },
  {
    title: "Pro Plan",
    description: "Unlock premium features with our Pro Plan, tailored for established businesses.",
    icon: "💫",
    color: "text-blue-400",
    features: [
      "6-Page Website",
      "Everything In Unlimited+",
      "AI ChatBot on Site",
      "Ongoing SEO Updates",
      "Google and Meta Ads Management",
      "4/Month Reel Video Editing Service",
      "Weekly Newsletter",
      "Bi-Monthly Marketing Consultation Calls"
    ]
  },
  {
    title: "A.i Plan",
    description: "Leverage cutting-edge technology with our A.i Plan, built for innovators.",
    icon: "🤖",
    color: "text-pink-400",
    features: [
      "8-Page Website",
      "Everything In Pro+",
      "A.i Conversation for Google and Meta",
      "A.i Lead Capture on Social Media Platforms",
      "A.i Booking System",
      "8/Month Reel Video Editing Service",
      "Premium 24/7 Support"
    ]
  },
  {
    title: "Ultra A.i Plan",
    description: "Most advanced technology in our Ultra A.i. Plan, built for franchises.",
    icon: "🌟",
    color: "text-green-400",
    features: [
      "Everything In A.i+",
      "A.i Cold Calling System",
      "Premium 24/7 Support"
    ]
  }
];

const testimonials = [
  {
    name: "John Smith",
    role: "Owner",
    company: "Elite Auto Detailing",
    testimonial: "MerkadAgency.ai transformed our business with their AI solutions. Our lead generation has increased by 300% since implementing their system.",
    rating: 5,
    image: "/placeholder.svg"
  },
  {
    name: "Sarah Johnson",
    role: "Manager",
    company: "Premium Car Care",
    testimonial: "The AI chatbot and automation tools have significantly reduced our response time and improved customer satisfaction.",
    rating: 5,
    image: "/placeholder.svg"
  },
  {
    name: "Michael Brown",
    role: "CEO",
    company: "Luxury Auto Spa",
    testimonial: "Their AI-powered marketing strategies have helped us reach new customers and grow our business exponentially.",
    rating: 5,
    image: "/placeholder.svg"
  }
];

const blogPosts = [
  {
    title: "The Future of Auto Detailing: AI-Driven Solutions",
    description: "Discover how artificial intelligence is revolutionizing the auto detailing industry and improving customer experience.",
    image: "/placeholder.svg",
    date: "March 15, 2024"
  },
  {
    title: "Maximizing ROI with AI Lead Generation",
    description: "Learn how auto detailing businesses are leveraging AI to generate and convert more leads effectively.",
    image: "/placeholder.svg",
    date: "March 10, 2024"
  },
  {
    title: "Automation Tools Every Auto Detailer Needs",
    description: "Explore the essential automation tools that can streamline your auto detailing business operations.",
    image: "/placeholder.svg",
    date: "March 5, 2024"
  }
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <QuickBenefits />
      <PricingSection pricingPlans={pricingPlans} />
      <BenefitsSection />
      <TestimonialsSection testimonials={testimonials} />
      <BlogSection blogPosts={blogPosts} />
      <Footer />
    </div>
  );
};

export default Index;
