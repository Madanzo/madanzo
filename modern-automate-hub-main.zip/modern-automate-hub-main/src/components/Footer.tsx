import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-background/50 backdrop-blur-sm">
      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About Us</h3>
            <p className="text-sm text-foreground/80 mb-4">
              Empowering auto detailing businesses with next-level AI tools and automation solutions.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-foreground/60 hover:text-primary"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="text-foreground/60 hover:text-primary"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="text-foreground/60 hover:text-primary"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="text-foreground/60 hover:text-primary"><Linkedin className="w-5 h-5" /></a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-foreground/80 hover:text-primary">About</a></li>
              <li><a href="#" className="text-sm text-foreground/80 hover:text-primary">Services</a></li>
              <li><a href="#" className="text-sm text-foreground/80 hover:text-primary">Blog</a></li>
              <li><a href="#" className="text-sm text-foreground/80 hover:text-primary">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2">
              <li className="flex items-center text-sm text-foreground/80">
                <Mail className="w-4 h-4 mr-2" /> info@merkadagency.ai
              </li>
              <li className="flex items-center text-sm text-foreground/80">
                <Phone className="w-4 h-4 mr-2" /> (555) 123-4567
              </li>
              <li className="flex items-center text-sm text-foreground/80">
                <MapPin className="w-4 h-4 mr-2" /> 123 AI Street, Tech City, TC 12345
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Newsletter</h3>
            <p className="text-sm text-foreground/80 mb-4">
              Subscribe to our newsletter for the latest updates and insights.
            </p>
            <div className="flex gap-2">
              <Input type="email" placeholder="Enter your email" className="bg-background" />
              <Button>Subscribe</Button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border pt-8 text-center text-sm text-foreground/60">
          <p>© 2024 MerkadAgency.ai. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;