import { Button } from "@/components/ui/button";
import { Play, ArrowRight } from "lucide-react";
import GeometricPattern from "./GeometricPattern";

const HeroSection = () => {
  return (
    <section className="relative min-h-[90vh] pt-32 pb-20 px-4 hero-gradient overflow-hidden">
      <GeometricPattern />
      
      {/* Centered radial gradient background with animation */}
      <div className="absolute inset-0 bg-gradient-radial from-purple-900/30 via-background/50 to-background pointer-events-none animate-pulse" />
      
      <div className="container mx-auto relative z-10">
        <div className="flex flex-col items-center justify-center text-center max-w-4xl mx-auto space-y-12 animate-fade-in">
          {/* Main content */}
          <div className="space-y-6">
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold tracking-tight leading-tight animate-fade-in">
              Elevate Your Auto Detailing Business with{" "}
              <span className="gradient-glow text-5xl sm:text-6xl md:text-8xl block mt-2 animate-float">
                AI Precision
              </span>
            </h1>
            
            <p className="text-lg sm:text-xl md:text-2xl text-foreground/80 max-w-2xl mx-auto font-light tracking-wide animate-fade-in-delayed leading-relaxed">
              From Lead Generation to Customer Retention—AI Tools Designed to Scale Your Success
            </p>
            
            <p className="text-base sm:text-lg text-foreground/60 animate-pulse">
              Powering Detailing Businesses 24/7 with AI
            </p>
          </div>
          
          {/* CTA Buttons with hover animations */}
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center animate-fade-in-delayed">
            <Button 
              size="lg" 
              className="group relative overflow-hidden bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-8 py-6 rounded-xl shadow-lg shadow-primary/20 transition-all duration-300 hover:scale-105 hover:shadow-xl"
            >
              Get Started Today
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 to-blue-400/20 animate-pulse" />
            </Button>
            
            <Button 
              variant="outline" 
              size="lg" 
              className="group bg-background/50 backdrop-blur-sm border-primary/50 hover:bg-background/70 text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-primary/10 hover:shadow-lg"
            >
              <Play className="mr-2 group-hover:scale-110 transition-transform" />
              See How It Works
            </Button>
          </div>
          
          {/* Microcopy with fade animation */}
          <p className="text-sm text-foreground/60 animate-fade-in-delayed">
            No credit card required • Instant setup
          </p>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;