import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Check } from "lucide-react";

interface PricingCardProps {
  title: string;
  description: string;
  features: string[];
  icon: string;
  color: string;
}

const PricingCard = ({ title, description, features, icon, color }: PricingCardProps) => {
  return (
    <Card className="flex flex-col h-full bg-card/30 backdrop-blur-sm border border-primary/10 hover:border-primary/30 transition-all duration-300 rounded-xl overflow-hidden group hover:shadow-lg hover:shadow-primary/5">
      <CardHeader className="space-y-4 p-6">
        <div className="flex items-center gap-3">
          <span className={`text-2xl ${color}`}>{icon}</span>
          <h3 className="text-xl font-bold tracking-tight">{title}</h3>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
      </CardHeader>
      <CardContent className="flex flex-col h-full p-6 pt-0">
        <ul className="space-y-3 mb-8 flex-grow">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-3 text-sm">
              <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
              <span className="text-foreground/90">{feature}</span>
            </li>
          ))}
        </ul>
        <Button 
          className="w-full bg-primary/90 hover:bg-primary transition-colors duration-300 text-white font-medium py-6"
          size="lg"
        >
          Contact Us
        </Button>
      </CardContent>
    </Card>
  );
};

export default PricingCard;