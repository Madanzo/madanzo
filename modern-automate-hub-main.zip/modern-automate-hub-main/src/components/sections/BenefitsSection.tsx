
import { Bot, BarChart, MessageSquare } from "lucide-react";

export const BenefitsSection = () => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-4 gradient-text">
          Why Choose MerkadAgency.ai?
        </h2>
        <p className="text-foreground/80 mb-12 max-w-2xl mx-auto text-lg">
          Experience the power of AI-driven solutions tailored for your auto detailing business
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300">
            <Bot className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">AI Chatbot Integration</h3>
            <p className="text-foreground/80">
              24/7 customer support and lead qualification with our advanced AI chatbot
            </p>
          </div>
          <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300">
            <BarChart className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Lead Management CRM</h3>
            <p className="text-foreground/80">
              Streamline your lead management process with our AI-powered CRM system
            </p>
          </div>
          <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300">
            <MessageSquare className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Google Reviews Automation</h3>
            <p className="text-foreground/80">
              Automatically collect and manage customer reviews to boost your online presence
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
