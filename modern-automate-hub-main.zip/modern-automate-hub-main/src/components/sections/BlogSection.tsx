
import BlogCard from "@/components/BlogCard";

interface BlogPost {
  title: string;
  description: string;
  image: string;
  date: string;
}

interface BlogSectionProps {
  blogPosts: BlogPost[];
}

export const BlogSection = ({ blogPosts }: BlogSectionProps) => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-4 gradient-text">
          Latest Insights
        </h2>
        <p className="text-foreground/80 mb-12 max-w-2xl mx-auto text-lg">
          Stay updated with the latest trends and insights in AI-powered auto detailing
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <BlogCard key={index} {...post} />
          ))}
        </div>
      </div>
    </section>
  );
};
