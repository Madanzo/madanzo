
import TestimonialCard from "@/components/TestimonialCard";

interface Testimonial {
  name: string;
  role: string;
  company: string;
  testimonial: string;
  rating: number;
  image: string;
}

interface TestimonialsSectionProps {
  testimonials: Testimonial[];
}

export const TestimonialsSection = ({ testimonials }: TestimonialsSectionProps) => {
  return (
    <section className="py-20 px-4 bg-gradient-radial from-background to-background/50">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-4 gradient-text">
          What Our Clients Are Saying
        </h2>
        <p className="text-foreground/80 mb-12 max-w-2xl mx-auto text-lg">
          Discover how we've helped auto detailing businesses grow with our AI solutions
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};
