
import PricingCard from "@/components/PricingCard";

interface PricingPlan {
  title: string;
  description: string;
  icon: string;
  color: string;
  features: string[];
}

interface PricingSectionProps {
  pricingPlans: PricingPlan[];
}

export const PricingSection = ({ pricingPlans }: PricingSectionProps) => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-5xl font-bold text-center mb-4 gradient-text">
          Explore Our Plans
        </h2>
        <p className="text-center text-foreground/80 mb-12 max-w-2xl mx-auto text-lg">
          Choose the perfect plan to elevate your auto detailing business with our AI-powered solutions
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 items-stretch">
          {pricingPlans.map((plan) => (
            <PricingCard key={plan.title} {...plan} />
          ))}
        </div>
      </div>
    </section>
  );
};
