import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

interface TestimonialCardProps {
  name: string;
  role: string;
  company: string;
  testimonial: string;
  rating: number;
  image: string;
}

const TestimonialCard = ({ name, role, company, testimonial, rating, image }: TestimonialCardProps) => {
  return (
    <Card className="bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <img src={image} alt={name} className="w-12 h-12 rounded-full object-cover" />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {Array.from({ length: rating }).map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-primary text-primary" />
              ))}
            </div>
            <p className="text-sm text-foreground/80 mb-4">{testimonial}</p>
            <div>
              <p className="font-semibold">{name}</p>
              <p className="text-sm text-foreground/60">{role} at {company}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TestimonialCard;