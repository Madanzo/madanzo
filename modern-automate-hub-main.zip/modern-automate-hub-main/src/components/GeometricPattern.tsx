import React from 'react';

const GeometricPattern = () => {
  return (
    <div className="absolute inset-0 w-full h-full bg-purple-950/20 overflow-hidden backdrop-blur-sm animate-fade-in">
      {/* Background grid with fade-in animation */}
      <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 gap-0 animate-fade-in">
        {Array(64).fill(null).map((_, index) => (
          <div 
            key={index} 
            className="relative w-full h-full border-[0.5px] border-purple-500/5"
            style={{
              animation: `fade-in ${0.1 + index * 0.01}s ease-out`
            }}
          />
        ))}
      </div>
      
      {/* Geometric shapes with staggered animations */}
      <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 gap-0">
        {Array(16).fill(null).map((_, index) => (
          <div 
            key={index} 
            className="relative w-full h-full group animate-fade-in"
            style={{
              animationDelay: `${index * 0.1}s`
            }}
          >
            <div 
              className="absolute inset-0 transform rotate-45 transition-all duration-500 hover:scale-110 animate-pulse"
              style={{
                background: 'linear-gradient(135deg, rgba(168,85,247,0.1) 0%, rgba(217,70,239,0.05) 100%)',
                clipPath: 'polygon(0 0, 100% 0, 50% 50%)',
                animation: `pulse ${2 + (index % 3)}s infinite ease-in-out`,
              }}
            />
            <div 
              className="absolute inset-0 transform -rotate-45 transition-all duration-500 group-hover:scale-90 animate-float"
              style={{
                background: 'linear-gradient(135deg, rgba(139,92,246,0.1) 0%, rgba(168,85,247,0.05) 100%)',
                clipPath: 'polygon(50% 50%, 100% 100%, 0 100%)',
                animation: `float ${3 + (index % 2)}s infinite ease-in-out`,
              }}
            />
          </div>
        ))}
      </div>

      {/* Animated overlay lines with glow effect */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-purple-500/30 to-transparent animate-glow" />
        <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-purple-500/30 to-transparent animate-glow" />
        <div className="absolute top-0 left-0 h-full w-[1px] bg-gradient-to-b from-transparent via-purple-500/30 to-transparent animate-glow" />
        <div className="absolute top-0 right-0 h-full w-[1px] bg-gradient-to-b from-transparent via-purple-500/30 to-transparent animate-glow" />
      </div>

      {/* Center accent with pulsing animation */}
      <div className="absolute inset-0 flex items-center justify-center opacity-50">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500/10 to-fuchsia-500/10 animate-pulse" />
      </div>
    </div>
  );
};

export default GeometricPattern;