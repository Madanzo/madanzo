import { Bot, BarChart, MessageSquare, Rocket } from "lucide-react";

const benefits = [
  {
    icon: Rocket,
    title: "Boost Google Rankings",
    description: "24/7 AI SEO Optimization",
  },
  {
    icon: BarChart,
    title: "Automate Lead Generation",
    description: "Smart CRM Management",
  },
  {
    icon: MessageSquare,
    title: "AI Chat Support",
    description: "24/7 Customer Engagement",
  },
  {
    icon: Bot,
    title: "Smart Automation",
    description: "Streamlined Operations",
  },
];

const QuickBenefits = () => {
  return (
    <div className="w-full overflow-hidden py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group hover:scale-105 transition-all duration-300 h-full"
            >
              <div className="h-full p-6 rounded-xl bg-card/50 backdrop-blur-sm border border-primary/20 hover:border-primary/50 transition-colors flex flex-col items-center">
                <benefit.icon className="w-12 h-12 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                <p className="text-foreground/80">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuickBenefits;