import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface BlogCardProps {
  title: string;
  description: string;
  image: string;
  date: string;
}

const BlogCard = ({ title, description, image, date }: BlogCardProps) => {
  return (
    <Card className="bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300">
      <div className="aspect-video relative overflow-hidden rounded-t-lg">
        <img src={image} alt={title} className="object-cover w-full h-full hover:scale-105 transition-transform duration-300" />
      </div>
      <CardHeader>
        <p className="text-sm text-foreground/60 mb-2">{date}</p>
        <CardTitle className="text-xl mb-2">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-foreground/80 mb-4 line-clamp-2">{description}</p>
        <Button variant="link" className="p-0 h-auto font-semibold">
          Read More <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </CardContent>
    </Card>
  );
};

export default BlogCard;